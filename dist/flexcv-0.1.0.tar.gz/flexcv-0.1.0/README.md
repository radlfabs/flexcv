# HSD: Soundscape Method Comparison

This repo hosts code to perform computations of the grand method comparison for indoor soundscape modelling for the upcoming paper Versümer, Rosenthal, Blättermann, Weinzierl und Co KG 2023.
This readme file will introduce you to the key modules and thoughts behind this code base. At the end of this readme, you will have installed a python environment to use with this project and will be able to reproduce some of our runs or start your own runs as well.

## Introduction
This repo allows for the following comparisons of
- Different datasets
- Different targets
- Different formulas / predictors
Also, we can
- Train a set of models
- Perform nested cross validation
- Tune hyperparameters in a fair fashion
- Estimate the generalization performance
- Compare models and folding variations
And finally we
- Log everything to Neptune.ai

The key modules for the computationally side are
`main.py` - includes the main function where everything is configured in and called from.
`cross_val.py` - includes nested cross validation, the core of our calculations.

As a user, you have the possibility to use the following entry points:
1) Regarding the dataset side of things:
    - `datasets.py` - Here we define which dataset names to use and link to a specific & custom loading function
    - `dataset_variables.py` - Offers custom functions regarding handling the DatasetVariableNames.xlsx table.
2) Regarding models and methods:
    - `model_mapping.py` - Defines a mapper object to configure models and their hyperparameter spaces. We also link to specific and custom postprocessing functions that are held in the module
    - `model_postprocessing.py` - Holds postprocessing functions e.g. with the specific plotting functionality that makes sense for model types.
3) The run configuration, i.e. the arguments passed to `main()`.

## Getting started
Install Python v3.10, e.g. using conda (Anaconda or Miniconda). We recommend using an fresh environment for cleanly holding all relevant packages corresponding to this repo.  With conda installed you can create a new Python 3.10 environment, activate it and install our requirements by running the following lines from the command line:
```bash
conda create --n hsd python=3.10
conda activate hsd
conda install pip
cd path/to/this/repo
pip install -r requirements.txt
```
Now you have installed everything you need to reproduce our computations.

## Implementation Overview
This chapter introduces some key objects in our implementation.
### `main`
- Gets a DataLoadConfigurator
- Calls logging
- Instantiates the `DataLoader`
- Calls our custom function to perform nested cross validation
- performs refitting of the median models
- Summarizes results and logs them

### `DataLoader`
- Is a dataclass
- `__post_init__`:
    - Calls preparation function of the chosen data set
    - Creates class attributes holding the data
- `get_data` returns X, y and group dataframes/series
- `to_excel` saves the dataframes to disk

### Custom preparation functions
Hereby we define functions that handle our data preprocessing. They are imported and passed in `datasets.py`. They implement the following:
- Reading in a data set from disk
- Concatenating different files if necessary
- Cleaning data
- Computing missing columns
- Renaming
- Rescaling
    
Returns: `pandas.DataFrame`. Note: You have to return a dataframe containing relevant columns corresponding to what you allow to load via `dataset_variables.py`.

### `cross_validate`
- Gets dataset and run configuration
- Creates dataclass instances for all the data used in the folds
- Assigns folds depending on the chosen cv-method
- Iterates over outer folds
- Creates inner cv-class to pass to models
- performs hyperparameter tuning with Optuna
    - Optuna iteratively creates 10 trials
    - each trial is 5-fold cross validated
    - selects model corresponding to best trial after cross validation  
- Calls estimator functions again with best hyperparameters
- Tracks median model regarding the $R^2$ score
- Makes results dictionary containing all relevant metrics and models
- it also allows for indepent scaling of outer and inner fold. That means, thze inner CV is never seeing data scaled in the outer fold. The outer fold scaling is only applied for data that is seen by our outer fold model in evaluation.  

### `CusomStratifiedGroupKFold`
This is our custom split strategy in outer CV to improve fairness and generalization in model evaluation.
- We stratify 10 quantiles of our target variable by discretizing the target variable and forcing the test fold to have the same distribution of quantiles (similar to multiclass stratification)
- We apply grouping rules:
    - every group will have been in test set at least once
    - groups will not be split, i.e. they will not leak from train to test fold
    - number of groups across splits will be approximately the same 

### Logging to Neptune
A few quick words on what you will get as return in a run: `main` is implemented to log everything (meta data, info, files, plots, everything; You get the idea) to a [neptune-account](www.neptune.ai). But you can not use `neptune_on` (see code example below) as long you have not created a `neptune_dict.py` that defines your API token. Therefore, either create your own Neptune account or add some code that saves your results to disk.

## Running `main`
In this little chapter we want to dive into how our `main`-function is called to reproduce all runs.
Since we have

1) Three datasets
2) Different target variables
3) Different model complexity levels

We need 3 loops in which `main` is called.
We do not hard code the string-based configurations, but import and map the needed instructions from the `datasets` module. Okay, we hardcode the model level range.

`Main` takes in the `RunConfigurator`, i.e. a `dataclass` holding the confuration attributes.
The `RunConfiurator` has a `DataLoadConfiguration`. In this dataclass we define everything that is useful for the `DataLoader` class to make a specific and unique data load operation corresponding to what we want to find out.
The aother arguments in this function call are regarding the configuration of our cross validation.
Of course, you do not need these many levels of indentation, if you only want to reproduce a single run. 

```python
if __name__ == "__main__":
    from datasets import DATASETS
    from dataset_variables import get_target
    from model_mapping import EM_MAX_ITER_PER_DATASET
    add_module_handlers(logger)

    for dataset in DATASETS.keys():
        targets = get_target(dataset)
        for target in targets:
            for model_level in range(1, 5):               
                    main(
                        RunConfigurator(
                            DataLoadConfiguration=DataLoadConfig(
                                dataset_name=dataset,
                                model_level=model_level,
                                target_name=target,
                            ),
                            cross_val_method=cross_val_classes.CrossValMethod.CUSTOM,
                            cross_val_method_in=cross_val_classes.CrossValMethod.KFOLD,
                            use_sklearn_pipeline=True,
                            neptune_on=False,
                            scale_in=True,
                            scale_out=True,
                            em_max_iterations=EM_MAX_ITER_PER_DATASET[dataset],
                            diagnostics=True,
                            n_splits=5
                        )
                    )
```
Note: `main` is implemented to log everything to a neptune-account. But you can not use `neptune_on` as long you have not created a `neptune_dict.py` that defines your API token. Therefore, either create your own Neptune account or add some code that saves your results to disk.


